import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        ArrayList<Integer> arr1 = new ArrayList<>(Arrays.asList(2,5));
        ArrayList<Integer> arr2 = new ArrayList<>(Arrays.asList(2,4));
        ArrayList<String> arr4 = new ArrayList<>(Arrays.asList("あ","い"));
        ArrayList<String> arr5 = new ArrayList<>(Arrays.asList("い","え", "お"));
    }

}

